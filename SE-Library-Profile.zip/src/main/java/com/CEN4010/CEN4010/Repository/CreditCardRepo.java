package com.CEN4010.CEN4010.Repository;

import com.CEN4010.CEN4010.Entity.CreditCard;
import com.CEN4010.CEN4010.Entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CreditCardRepo extends JpaRepository<CreditCard,Integer>{
}



