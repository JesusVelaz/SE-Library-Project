package com.CEN4010.CEN4010;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cen4010ApplicationTests {

	@Test
	void contextLoads() {
	}

}
